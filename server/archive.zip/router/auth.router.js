"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_controller_1 = require("../controllers/auth.controller");
const users_validator_1 = require("../validators/users.validator");
const authRouter = (0, express_1.Router)();
authRouter.post("/register", // * URI
users_validator_1.createUserValidator, // ! Validator
auth_controller_1.registerHandler // ? Handler
);
authRouter.post("/login", // * URI
users_validator_1.loginUserValidator, // ! Validator
auth_controller_1.loginHandler // ? Handler
);
exports.default = authRouter;
