"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const student_controller_1 = require("../controllers/student.controller");
const auth_middleware_1 = require("../utils/middlewares/auth.middleware");
const students_validator_1 = require("../validators/students.validator");
const studentRouter = (0, express_1.Router)();
studentRouter.get("/", // * URI
auth_middleware_1.authGuard, // ! Middleware
student_controller_1.getListHandler // ? Handler
);
studentRouter.get("/:id", // * URI
auth_middleware_1.authGuard, // ! Middleware
student_controller_1.getByIdHandler // ? Handler
);
studentRouter.post("/", // * URI
auth_middleware_1.authGuard, // ! Middleware
students_validator_1.createStudentValidator, // ! Validator
student_controller_1.createHandler // ? Handler
);
exports.default = studentRouter;
