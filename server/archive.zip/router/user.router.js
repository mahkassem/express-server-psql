"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const userRouter = (0, express_1.Router)();
userRouter.get("/:id", (req, res) => {
    res.send(`Your user id is: ${req.params.id}`);
});
exports.default = userRouter;
