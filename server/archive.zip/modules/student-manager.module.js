"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class StudentManager {
    constructor(student) {
        this.student = student;
    }
    // getters
    getName() {
        return this.student.name;
    }
    getAge() {
        return this.student.age;
    }
    getHobbies() {
        return this.student.hobbies;
    }
    // setters
    setName(name) {
        this.student.name = name;
    }
    setAge(age) {
        this.student.age = age;
    }
    setHobbies(hobbies) {
        this.student.hobbies = hobbies;
    }
    addHooby(hobby) {
        this.student.hobbies.push(hobby);
    }
}
exports.default = StudentManager;
