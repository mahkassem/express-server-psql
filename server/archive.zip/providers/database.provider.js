"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
const pg_1 = require("pg");
const env_helper_1 = __importDefault(require("../utils/helpers/env.helper"));
const appEnv = (_a = (0, env_helper_1.default)("ENV")) !== null && _a !== void 0 ? _a : "dev";
const db = new pg_1.Pool({
    user: (0, env_helper_1.default)("DB_USER"),
    host: (0, env_helper_1.default)("DB_HOST"),
    database: appEnv === "test" ? (0, env_helper_1.default)("DB_TEST_NAME") : (0, env_helper_1.default)("DB_NAME"),
    password: (0, env_helper_1.default)("DB_PASS"),
    port: parseInt((0, env_helper_1.default)("DB_PORT")),
});
exports.default = db;
