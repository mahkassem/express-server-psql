"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getListHandler = exports.getByIdHandler = exports.createHandler = void 0;
const auth_service_1 = __importDefault(require("../services/auth.service"));
const student_service_1 = __importDefault(require("../services/student.service"));
const mail_service_1 = require("../services/mail.service");
const _authService = new auth_service_1.default();
const _studentService = new student_service_1.default();
const getListHandler = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const options = req.query;
    const students = yield _studentService.getList(options);
    res.json(students);
    return;
});
exports.getListHandler = getListHandler;
const createHandler = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        // get user and student from request body
        const { user, student } = req.body;
        // use user service to create user
        const createdUser = yield _authService.register(user);
        student.user_id = createdUser.id;
        // use student service to create student
        const createdStudent = yield _studentService.create(student);
        createdStudent.user = createdUser;
        // send email to user
        (0, mail_service_1.sendMail)({
            to: `${createdUser.name} <${createdUser.username}>`,
            subject: "Welcome to Student Management System",
            text: `Hi ${createdUser.name}, welcome to Student Management System.`
        });
        // return user
        res.status(201).send(createdStudent);
    }
    catch (error) {
        res.status(500).send((_a = error.message) !== null && _a !== void 0 ? _a : "Internal server error");
    }
    return;
});
exports.createHandler = createHandler;
const getByIdHandler = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // get id from request params
        const { id } = req.params;
        // use student service to get student by id
        const student = yield _studentService.getByIdWithUser(parseInt(id));
        // return student
        res.status(200).send(student);
    }
    catch (error) {
        res.status(500).send("Internal server error");
    }
    return;
});
exports.getByIdHandler = getByIdHandler;
